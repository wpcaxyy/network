./tools/dist_train.sh configs/sem_fpn/fpn_lsnet_t_ade20k_40k.py 8 --seed 0 --deterministic
